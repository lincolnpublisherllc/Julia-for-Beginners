using Pkg
Pkg.add("Plots")
