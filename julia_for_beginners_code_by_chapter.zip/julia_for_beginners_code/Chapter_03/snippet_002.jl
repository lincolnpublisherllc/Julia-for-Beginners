println() is a function that tells Julia to print something to the screen.
