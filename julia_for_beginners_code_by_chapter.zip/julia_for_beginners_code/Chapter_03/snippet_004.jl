x = 10
y = 5
result = x + y
println("The result of ", x, " + ", y, " is: ", result)
