The result of 10 + 5 is: 15
