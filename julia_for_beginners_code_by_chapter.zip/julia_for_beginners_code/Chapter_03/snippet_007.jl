ERROR: UndefVarError: reuslt not defined
