println("The result of ", x, " + ", y, " is: ", result)
