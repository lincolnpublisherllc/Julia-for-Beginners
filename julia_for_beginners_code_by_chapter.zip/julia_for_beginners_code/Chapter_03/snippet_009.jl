println("Enter the first number:")
num1 = parse(Int, readline())
