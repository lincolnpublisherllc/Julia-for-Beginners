println("Enter the second number:")
num2 = parse(Int, readline())
