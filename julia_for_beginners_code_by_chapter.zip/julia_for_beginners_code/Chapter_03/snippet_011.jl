sum = num1 + num2
println("The sum is: ", sum)
