age = 25
println(age)  # Output: 25
age = 30
println(age)  # Output: 30
