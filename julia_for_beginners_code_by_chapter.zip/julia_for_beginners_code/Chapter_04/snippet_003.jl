x = 42        # Integer
y = -100      # Integer
