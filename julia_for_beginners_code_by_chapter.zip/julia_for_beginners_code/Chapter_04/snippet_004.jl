pi = 3.14159   # Float64
temperature = -12.5  # Float64
