name = "John Doe"  # String
greeting = "Hello, World!"  # String
