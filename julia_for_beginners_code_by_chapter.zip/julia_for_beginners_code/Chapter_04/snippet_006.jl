is_active = true      # Boolean
has_permission = false  # Boolean
