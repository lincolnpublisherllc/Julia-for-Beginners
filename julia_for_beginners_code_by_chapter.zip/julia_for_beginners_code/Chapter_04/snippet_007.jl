numbers = [1, 2, 3, 4, 5]      # Array of integers
colors = ["red", "green", "blue"]  # Array of strings
