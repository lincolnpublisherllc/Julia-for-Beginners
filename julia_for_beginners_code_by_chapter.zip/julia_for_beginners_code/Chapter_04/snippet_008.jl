point = (3, 4)         # Tuple of two integers
name_and_age = ("John", 30)  # Tuple of a string and an integer
