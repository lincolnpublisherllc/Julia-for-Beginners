x = 42
y = 3.14
name = "Julia"
is_active = true
