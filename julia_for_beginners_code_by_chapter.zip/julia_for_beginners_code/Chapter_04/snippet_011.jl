println(typeof(x))      # Output: Int64
println(typeof(y))      # Output: Float64
println(typeof(name))   # Output: String
println(typeof(is_active))  # Output: Bool
