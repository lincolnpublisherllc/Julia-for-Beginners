Int() – Converts a value to an integer.
Float64() – Converts a value to a floating-point number.
String() – Converts a value to a string.
