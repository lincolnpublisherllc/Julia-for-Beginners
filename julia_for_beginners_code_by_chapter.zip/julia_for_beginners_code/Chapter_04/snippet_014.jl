# Converting types
x_int = Int(x)           # Convert Float64 to Int (will truncate the decimal)
y_int = Int(y)           # Convert String to Int
z_float = Float64(z)     # Convert Int to Float64
