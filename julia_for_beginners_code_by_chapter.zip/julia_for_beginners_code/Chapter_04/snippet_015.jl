println(x_int)      # Output: 3
println(y_int)      # Output: 42
println(z_float)    # Output: 10.0
