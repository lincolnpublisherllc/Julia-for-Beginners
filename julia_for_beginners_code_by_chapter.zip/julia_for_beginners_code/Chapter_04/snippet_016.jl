# Variable assignments
name = "Julia"
age = 28
height = 1.75
is_student = true
