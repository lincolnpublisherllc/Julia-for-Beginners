# Displaying variable types and values
println("Name: ", name)
println("Age: ", age)
println("Height: ", height)
println("Is a student: ", is_student)
