# Checking the types
println("Type of name: ", typeof(name))
println("Type of age: ", typeof(age))
println("Type of height: ", typeof(height))
println("Type of is_student: ", typeof(is_student))
