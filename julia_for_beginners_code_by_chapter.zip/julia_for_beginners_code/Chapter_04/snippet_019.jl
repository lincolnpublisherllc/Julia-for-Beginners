Name: Julia
Age: 28
Height: 1.75
Is a student: true
Type of name: String
Type of age: Int64
Type of height: Float64
Type of is_student: Bool
