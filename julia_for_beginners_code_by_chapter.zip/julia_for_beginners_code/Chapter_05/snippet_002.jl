sum = a + b         # Addition
difference = a - b  # Subtraction
product = a * b     # Multiplication
quotient = a / b    # Division
integer_quotient = a ÷ b  # Integer Division
remainder = a % b   # Modulo (Remainder)
power = a^b         # Exponentiation
