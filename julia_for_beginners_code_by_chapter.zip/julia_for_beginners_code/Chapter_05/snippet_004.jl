Sum: 15
Difference: 5
Product: 50
Quotient: 2.0
Integer Quotient: 2
Remainder: 0
Power: 100000
