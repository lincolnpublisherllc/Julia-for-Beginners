println("x == y: ", x == y)  # Equal to
println("x != y: ", x != y)  # Not equal to
println("x > y: ", x > y)    # Greater than
println("x < y: ", x < y)    # Less than
println("x >= y: ", x >= y)  # Greater than or equal to
println("x <= y: ", x <= y)  # Less than or equal to
