x == y: false
x != y: true
x > y: true
x < y: false
x >= y: true
x <= y: false
