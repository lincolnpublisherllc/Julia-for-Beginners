println("a && b: ", a && b)  # AND
println("a || b: ", a || b)  # OR
println("!a: ", !a)          # NOT
