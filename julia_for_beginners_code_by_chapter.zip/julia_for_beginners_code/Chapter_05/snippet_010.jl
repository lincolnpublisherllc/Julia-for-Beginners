a && b: false
a || b: true
!a: false
