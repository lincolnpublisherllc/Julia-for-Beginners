# Combining operators and variables in an expression
result = (x + y) * z / 3 - 4
