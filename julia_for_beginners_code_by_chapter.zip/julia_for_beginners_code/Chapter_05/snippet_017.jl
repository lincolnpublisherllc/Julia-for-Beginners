Result: 10.0
