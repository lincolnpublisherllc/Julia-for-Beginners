if condition
    # Code to execute if condition is true
else
    # Code to execute if condition is false
end
