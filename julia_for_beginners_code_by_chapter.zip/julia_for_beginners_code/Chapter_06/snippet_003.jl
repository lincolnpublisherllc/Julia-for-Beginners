if x > y
    println("x is greater than y")
else
    println("x is not greater than y")
end
