if condition1
    # Code to execute if condition1 is true
elseif condition2
    # Code to execute if condition2 is true
else
    # Code to execute if both conditions are false
end
