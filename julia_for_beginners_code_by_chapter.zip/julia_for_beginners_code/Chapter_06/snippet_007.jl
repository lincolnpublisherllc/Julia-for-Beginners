if x > 20
    println("x is greater than 20")
elseif x == 15
    println("x is equal to 15")
else
    println("x is less than 15")
end
