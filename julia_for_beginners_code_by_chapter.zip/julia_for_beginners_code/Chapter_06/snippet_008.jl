x is equal to 15
