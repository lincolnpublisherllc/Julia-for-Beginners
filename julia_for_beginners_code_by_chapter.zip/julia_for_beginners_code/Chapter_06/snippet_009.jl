for variable in range_or_collection
    # Code to execute for each iteration
end
