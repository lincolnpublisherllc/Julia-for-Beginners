while condition
    # Code to execute while condition is true
end
