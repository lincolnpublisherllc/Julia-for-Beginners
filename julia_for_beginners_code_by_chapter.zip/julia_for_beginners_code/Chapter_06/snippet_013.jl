counter = 1
