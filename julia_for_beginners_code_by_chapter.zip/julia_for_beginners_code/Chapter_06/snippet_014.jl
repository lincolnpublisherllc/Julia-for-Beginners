while counter <= 5
    println("Counter is: ", counter)
    counter += 1   # Increment the counter by 1
end
