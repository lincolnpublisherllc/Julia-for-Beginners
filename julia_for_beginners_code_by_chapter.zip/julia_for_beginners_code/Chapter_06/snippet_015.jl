Counter is: 1
Counter is: 2
Counter is: 3
Counter is: 4
Counter is: 5
