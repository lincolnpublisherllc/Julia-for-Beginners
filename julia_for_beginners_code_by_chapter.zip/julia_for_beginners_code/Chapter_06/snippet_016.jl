for i in 1:3
    if i % 2 == 0
        println(i, " is even")
    else
        println(i, " is odd")
    end
end
