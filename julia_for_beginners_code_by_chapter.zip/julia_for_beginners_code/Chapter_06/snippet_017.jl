1 is odd
2 is even
3 is odd
