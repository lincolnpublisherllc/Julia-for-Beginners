for i in 1:3
    for j in 1:2
        println("i = ", i, ", j = ", j)
    end
end
