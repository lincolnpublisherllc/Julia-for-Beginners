println("Hello, ", name, "!") is the body of the function, where the greeting message is printed.
