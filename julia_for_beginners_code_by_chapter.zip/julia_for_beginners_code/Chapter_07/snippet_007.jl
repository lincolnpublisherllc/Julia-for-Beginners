return x + y returns the sum of x and y.
