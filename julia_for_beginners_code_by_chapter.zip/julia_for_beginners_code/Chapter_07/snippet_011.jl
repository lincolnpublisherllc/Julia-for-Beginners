greet()         # Will use the default value "Guest"
greet("John")   # Will use the value "John"
