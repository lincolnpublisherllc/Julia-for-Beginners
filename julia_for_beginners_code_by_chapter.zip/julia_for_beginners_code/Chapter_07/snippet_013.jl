function calculate(x, y)
    sum = x + y
    difference = x - y
    return sum, difference
end
