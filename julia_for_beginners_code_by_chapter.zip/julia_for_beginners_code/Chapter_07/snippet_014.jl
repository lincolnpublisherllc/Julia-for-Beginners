result_sum, result_diff = calculate(10, 5)
println("Sum: ", result_sum)
println("Difference: ", result_diff)
