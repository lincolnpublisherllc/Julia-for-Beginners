Sum: 15
Difference: 5
