result = calculate(10, 5)
println(result)
