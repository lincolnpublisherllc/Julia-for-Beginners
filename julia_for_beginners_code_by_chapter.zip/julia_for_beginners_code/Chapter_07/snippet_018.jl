f = x -> x^2
