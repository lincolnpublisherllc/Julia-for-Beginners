println(f(4))  # Output: 16
