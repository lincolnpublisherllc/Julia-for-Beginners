function print_square(x)
    println("The square of ", x, " is: ", x^2)
end
