fruits = ["apple", "banana", "cherry", "date"]
