println(fruits[1])   # Output: apple
println(fruits[3])   # Output: cherry
