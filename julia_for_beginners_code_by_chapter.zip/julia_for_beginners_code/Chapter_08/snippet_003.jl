fruits[2] = "blueberry"  # Replace "banana" with "blueberry"
println(fruits)  # Output: ["apple", "blueberry", "cherry", "date"]
