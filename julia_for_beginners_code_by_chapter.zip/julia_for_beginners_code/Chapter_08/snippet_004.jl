push!(fruits, "elderberry")
println(fruits)  # Output: ["apple", "blueberry", "cherry", "date", "elderberry"]
