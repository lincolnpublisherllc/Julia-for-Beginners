pop!(fruits)
println(fruits)  # Output: ["apple", "blueberry", "cherry", "date"]
