println(matrix[1, 2])  # Output: 2 (first row, second column)
println(matrix[3, 1])  # Output: 7 (third row, first column)
