matrix[2, 3] = 10  # Change the value in the second row, third column
println(matrix)     # Output: [1 2 3; 4 5 10; 7 8 9]
