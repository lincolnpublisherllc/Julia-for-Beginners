person = Dict("name" => "Alice", "age" => 30, "city" => "New York")
