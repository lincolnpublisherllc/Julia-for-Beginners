println(person["name"])  # Output: Alice
println(person["age"])   # Output: 30
