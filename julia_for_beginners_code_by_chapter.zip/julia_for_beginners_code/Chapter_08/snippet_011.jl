person["age"] = 31  # Update the age
println(person)  # Output: Dict("name" => "Alice", "age" => 31, "city" => "New York")
