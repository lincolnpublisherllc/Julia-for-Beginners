person["email"] = "alice@example.com"
println(person)  # Output: Dict("name" => "Alice", "age" => 31, "city" => "New York", "email" => "alice@example.com")
