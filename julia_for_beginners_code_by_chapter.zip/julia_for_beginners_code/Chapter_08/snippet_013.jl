delete!(person, "email")
println(person)  # Output: Dict("name" => "Alice", "age" => 31, "city" => "New York")
