students = Dict(
    "Alice" => [90, 85, 92],  # Alice's grades
    "Bob" => [78, 88, 94],    # Bob's grades
    "Charlie" => [92, 89, 84]  # Charlie's grades
)
