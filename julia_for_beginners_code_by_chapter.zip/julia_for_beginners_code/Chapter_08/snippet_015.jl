println(students["Alice"])  # Output: [90, 85, 92]
