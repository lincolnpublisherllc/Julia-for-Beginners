ERROR: syntax: extra token "end of file" after end of expression
