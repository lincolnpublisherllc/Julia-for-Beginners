a = [1, 2, 3]
println(a[4])  # Trying to access an element that doesn't exist
