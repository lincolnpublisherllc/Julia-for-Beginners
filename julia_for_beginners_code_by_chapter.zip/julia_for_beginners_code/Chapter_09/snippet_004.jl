ERROR: BoundsError: attempt to access 3-element Array{Int64,1} at index [4]
