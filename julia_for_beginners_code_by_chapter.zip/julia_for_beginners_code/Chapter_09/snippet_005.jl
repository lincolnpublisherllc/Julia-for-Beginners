function add_numbers(x, y)
    return x - y  # Incorrect operation (should be addition)
end
println(add_numbers(5, 3))  # Expected: 8, Actual: 2
