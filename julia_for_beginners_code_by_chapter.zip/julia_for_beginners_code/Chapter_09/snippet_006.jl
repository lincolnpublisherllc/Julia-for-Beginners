x = 10
y = 0
println(x / y)  # Division by zero
