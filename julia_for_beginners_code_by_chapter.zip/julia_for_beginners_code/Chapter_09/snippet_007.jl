ERROR: DivisionError: integer division or modulo by zero
