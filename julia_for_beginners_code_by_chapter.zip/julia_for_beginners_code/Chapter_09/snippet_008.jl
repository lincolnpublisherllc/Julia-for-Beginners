if y != 0
    println(x / y)
else
    println("Cannot divide by zero")
end
