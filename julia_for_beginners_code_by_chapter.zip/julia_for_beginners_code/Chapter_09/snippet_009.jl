function calculate_area(radius)
    println("Radius: ", radius)  # Print the radius value
    area = 3.14159 * radius^2
    println("Area: ", area)  # Print the area value
    return area
end
