calculate_area(5)
