function faulty_function(x, y)
    z = x + y
    return z / 0  # Division by zero error
end
