@enter faulty_function(10, 5)
