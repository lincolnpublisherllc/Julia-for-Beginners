try
    # Code that might cause an error
catch e
    # Code to handle the error (e.g., print a message)
    println("An error occurred: ", e)
end
