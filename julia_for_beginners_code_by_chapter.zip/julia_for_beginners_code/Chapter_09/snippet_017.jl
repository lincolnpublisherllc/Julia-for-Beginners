function safe_divide(x, y)
    try
        result = x / y
        return result
    catch e
        println("Error: ", e)
        return nothing  # Return nothing if an error occurs
    end
end
