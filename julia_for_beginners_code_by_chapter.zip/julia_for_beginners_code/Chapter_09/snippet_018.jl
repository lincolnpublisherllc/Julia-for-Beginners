println(safe_divide(10, 0))  # Division by zero
