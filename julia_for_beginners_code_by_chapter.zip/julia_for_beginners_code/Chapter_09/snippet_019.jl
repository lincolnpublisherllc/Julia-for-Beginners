Error: DivisionError: integer division or modulo by zero
