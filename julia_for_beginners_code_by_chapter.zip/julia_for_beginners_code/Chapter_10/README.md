# Chapter 10

Detected 12 code snippet(s) in this chapter.

- `snippet_001.jl`
- `snippet_002.jl`
- `snippet_003.jl`
- `snippet_004.jl`
- `snippet_005.jl`
- `snippet_006.jl`
- `snippet_007.jl`
- `snippet_008.jl`
- `snippet_009.jl`
- `snippet_010.jl`
- `snippet_011.jl`
- `snippet_012.jl`
