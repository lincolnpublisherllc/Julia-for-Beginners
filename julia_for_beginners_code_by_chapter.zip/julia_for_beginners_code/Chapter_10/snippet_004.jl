function divide(x, y)
    if y == 0
        println("Error: Division by zero is not allowed.")
        return nothing
    else
        return x / y
    end
end
