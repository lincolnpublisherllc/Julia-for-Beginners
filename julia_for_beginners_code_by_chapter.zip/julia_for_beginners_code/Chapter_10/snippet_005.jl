function calculator()
    println("Welcome to the Julia Calculator!")
