    # Getting input from the user
    print("Enter the first number: ")
    x = parse(Float64, readline())
