    print("Enter the second number: ")
    y = parse(Float64, readline())
