    println("Choose an operation: +, -, *, /")
    operation = readline()
