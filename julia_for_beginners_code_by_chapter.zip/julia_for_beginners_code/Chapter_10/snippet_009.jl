    # Perform the operation based on the user's choice
    result = nothing
    if operation == "+"
        result = add(x, y)
    elseif operation == "-"
        result = subtract(x, y)
    elseif operation == "*"
        result = multiply(x, y)
    elseif operation == "/"
        result = divide(x, y)
    else
        println("Invalid operation! Please choose +, -, *, or /.")    
    end
