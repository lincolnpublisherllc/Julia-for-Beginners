    # Displaying the result
    if result !== nothing
        println("The result is: ", result)
    end
end
