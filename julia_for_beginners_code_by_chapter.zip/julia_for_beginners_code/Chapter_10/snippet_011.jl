# Call the calculator function to run the program
calculator()
