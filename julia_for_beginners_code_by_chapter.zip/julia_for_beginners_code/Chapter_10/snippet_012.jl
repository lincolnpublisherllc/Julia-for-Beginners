Welcome to the Julia Calculator!
Enter the first number: 10
Enter the second number: 5
Choose an operation: +, -, *, /
+
The result is: 15.0
