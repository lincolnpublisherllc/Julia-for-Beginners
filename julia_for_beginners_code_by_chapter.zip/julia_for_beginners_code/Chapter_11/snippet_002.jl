if x > 10
    println("Greater than 10")
# Missing the 'end' here
