x = "Hello"
x = x + 5  # Error: cannot add string and integer
