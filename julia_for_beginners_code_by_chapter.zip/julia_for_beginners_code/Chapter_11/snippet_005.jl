x = 10
x = 20
println(x)  # Prints 20, but maybe you intended to keep the original value
