println(x)  # Error: variable x is not defined
