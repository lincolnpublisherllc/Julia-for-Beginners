add(5)  # Error: missing argument for y
