println(multiply(5, 3))  # Output: nothing
