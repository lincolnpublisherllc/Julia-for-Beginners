x = 10
if x > 5
    println("Greater than 5")
elseif x < 5
    println("Less than 5")
else
    println("Equal to 5")
