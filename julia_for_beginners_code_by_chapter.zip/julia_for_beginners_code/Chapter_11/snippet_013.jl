x = 1
while x > 0
    println(x)
    # No code to change x, so this loop runs forever
end
