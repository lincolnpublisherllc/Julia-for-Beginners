arr = [1, 2, 3]
println(arr[4])  # Error: out-of-bounds access
