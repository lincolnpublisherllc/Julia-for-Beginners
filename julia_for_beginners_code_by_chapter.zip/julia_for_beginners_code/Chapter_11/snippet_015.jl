arr = [10, 20, 30]
println(arr[4])  # Error: out-of-bounds access
