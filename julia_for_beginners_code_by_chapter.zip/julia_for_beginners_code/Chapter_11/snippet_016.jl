dict = Dict("name" => "Alice", "age" => 25)
println(dict["address"])  # Error: key "address" not found
