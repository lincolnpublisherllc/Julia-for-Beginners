println(get(dict, "address", "Not Available"))  # Output: Not Available
