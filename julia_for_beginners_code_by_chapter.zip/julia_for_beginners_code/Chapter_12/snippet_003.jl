function function_name(parameter1, parameter2)
    # Code
end
