if condition
    # Code
elseif another_condition
    # Code
else
    # Code
end
