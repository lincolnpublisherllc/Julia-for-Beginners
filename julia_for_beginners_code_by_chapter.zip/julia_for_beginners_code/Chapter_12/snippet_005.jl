for i in 1:10
    # Code
end
