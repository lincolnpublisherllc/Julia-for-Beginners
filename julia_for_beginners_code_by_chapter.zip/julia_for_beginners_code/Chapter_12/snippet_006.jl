while condition
    # Code
end
