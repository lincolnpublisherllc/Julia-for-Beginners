try
    # Code
catch e
    println("Error: ", e)
end
